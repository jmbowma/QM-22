The ab initio data file for the NaCl-H2 system follows this format:

Number of atoms

Interaction Energy (in Hartree)

Atom label and Cartesian coordinates (in Angstrom)

Note that these interaction energies are determined using the CCSD(T) level of theory and the aug-cc-pVTZ basis set with Molpro. The data file contains a total of 281,031 ab initio data sets
